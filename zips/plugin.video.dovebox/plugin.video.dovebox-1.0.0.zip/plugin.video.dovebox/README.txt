Feel Free to use any of the Eggz n Bacon and Salvation software, just remember where it came from, 
and give credit where its due please. A shout to Mick3yB0y is all thats required.

If any one requires any help, i am only too pleased if i can be of assistance.

All of the Eggz n Bacon and Salvation family are run and made by me, i am a solitary volunteer who does 
this as a hobby, so if things go down, i will get round to fixing them.

Have fun guys and girls.