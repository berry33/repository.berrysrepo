import xbmcaddon, xbmc

MainBase = ('http://berryburchett.net/kodi/xmls/main.xml')							
addon 	 = xbmcaddon.Addon('plugin.video.dovebox')